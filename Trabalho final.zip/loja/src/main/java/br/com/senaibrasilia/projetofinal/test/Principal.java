package br.com.senaibrasilia.projetofinal.test;

import java.math.BigDecimal;
import java.util.List;

import javax.persistence.EntityManager;

import br.com.senaibrasilia.projetofinal.dao.CategoriaDao;
import br.com.senaibrasilia.projetofinal.dao.ProdutoDao;
import br.com.senaibrasilia.projetofinal.model.Categoria;
import br.com.senaibrasilia.projetofinal.model.Produto;
import br.com.senaibrasilia.projetofinal.util.JPAUtil;

public class Principal {

	private static EntityManager em = JPAUtil.getEntityManager();
	private static ProdutoDao produtoDAO = new ProdutoDao(em);
	private static CategoriaDao categoriaDao = new CategoriaDao(em);
		 private static void cadastrarProduto() {
		        Categoria notebook = new Categoria("Notebooks");
		        Categoria celulares = new Categoria("Celulares");
		        
		        Produto celular = new Produto("Dell XPS", "Desempenho de Sobra", new BigDecimal("5000"), notebook );
		        Produto notebooks = new Produto("MacBook M1", "Desempenho puro", new BigDecimal("9000"), notebook );
		        Produto notebook1 = new Produto("Vostro", "produto Dell",new BigDecimal("3000"),notebook);
		       
		       
		        em.getTransaction().begin();
		       
		        categoriaDao.cadastrar(celulares);
		        categoriaDao.cadastrar(notebook);
		        produtoDAO.cadastrar(celular);
		        produtoDAO.cadastrar(notebooks); 
		        produtoDAO.cadastrar(notebook1);
		       
		       //produtoDAO.pesquisarPorCodigo(2);
		        //produtoDAO.remover(notebooks);
		       //produtoDAO.atualizar(notebook1);
		        
		        em.close();
		        em.getTransaction().commit();   
		    }
		 
		    public static void main(String[] args) {
		        cadastrarProduto();
		        EntityManager em = JPAUtil.getEntityManager();
		        ProdutoDao produtoDao = new ProdutoDao(em);
		       
		        Produto p = produtoDao.buscarPorId(1l);
		        System.out.println(p.getPreco());
		       
		        List<Produto> todos = produtoDao.buscarPorNomeDaCategoria("Notebooks");
		        todos.forEach(p2 -> System.out.println(p.getNome()));
		        
		      
		   
		    }
		 

}